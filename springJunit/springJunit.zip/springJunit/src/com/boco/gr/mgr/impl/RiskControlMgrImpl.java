package com.boco.gr.mgr.impl;

public class RiskControlMgrImpl {

}
