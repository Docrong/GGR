package com.example.demo;

public class Temp {

	public static void main(String[] args) {
		
		System.out.println(4>>1<<1);
	}
}
